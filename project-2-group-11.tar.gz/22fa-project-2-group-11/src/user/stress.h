#pragma once

void hang(void);

void nohang(void);

void recur(void);
